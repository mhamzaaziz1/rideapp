<?php

namespace Modules\Fleet\Controllers;

use App\Controllers\BaseController;
use Modules\Fleet\Models\DriverModel;

class DriversController extends BaseController
{
    protected $driverModel;

    public function __construct()
    {
        $this->driverModel = new DriverModel();
    }

    public function index()
    {
        $data = [];
        
        try {
            $data['drivers'] = $this->driverModel->findAll();
            $data['total_drivers'] = $this->driverModel->countAll();
            $data['active_drivers'] = $this->driverModel->where('status', 'active')->countAllResults();
            $data['inactive_drivers'] = $this->driverModel->where('status', 'inactive')->countAllResults();
            $data['total_trips'] = $this->driverModel->selectSum('total_trips')->first()->total_trips ?? 0;
        } catch (\Exception $e) {
            // Fallback for when DB table issues exist during dev
            $data['error'] = $e->getMessage();
            $data['drivers'] = [];
            $data['total_drivers'] = 0;
            $data['active_drivers'] = 0;
            $data['inactive_drivers'] = 0;
            $data['total_trips'] = 0;
        }

        $data['title'] = 'Driver Management';
        
        return view('Modules\Fleet\Views\drivers\index', $data);
    }
    public function create()
    {
        $rules = $this->driverModel->getValidationRules();
        
        // Remove 'id' from rules if it exists (usually not for insert, but good practice)
        
        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        $data = $this->request->getPost();

        // Handle File Uploads (KYC + Images)
        $fileFields = ['doc_license_front', 'doc_license_back', 'doc_id_proof', 'avatar', 'vehicle_image'];
        foreach ($fileFields as $field) {
            $file = $this->request->getFile($field);
            if ($file && $file->isValid() && !$file->hasMoved()) {
                $newName = $file->getRandomName();
                $file->move(ROOTPATH . 'public/uploads/drivers', $newName);
                $data[$field] = 'uploads/drivers/' . $newName;
            }
        }

        if ($this->driverModel->save($data)) {
            return redirect()->to('/drivers')->with('success', 'Driver added successfully.');
        }

        return redirect()->back()->withInput()->with('errors', $this->driverModel->errors());
    }

    public function edit($id)
    {
        $driver = $this->driverModel->find($id);
        if (!$driver) {
            return redirect()->to('/drivers')->with('error', 'Driver not found');
        }

        $data = [
            'driver' => $driver,
            'title' => 'Edit Driver'
        ];

        return view('Modules\Fleet\Views\drivers\form', $data);
    }

    public function update($id)
    {
        $driver = $this->driverModel->find($id);
        if (!$driver) {
            return redirect()->to('/drivers')->with('error', 'Driver not found');
        }

        $data = $this->request->getPost();
        
        // Handle File Uploads (Optional on update)
        $fileFields = ['doc_license_front', 'doc_license_back', 'doc_id_proof', 'avatar', 'vehicle_image'];
        foreach ($fileFields as $field) {
            $file = $this->request->getFile($field);
            if ($file && $file->isValid() && !$file->hasMoved()) {
                $newName = $file->getRandomName();
                $file->move(ROOTPATH . 'public/uploads/drivers', $newName);
                $data[$field] = 'uploads/drivers/' . $newName;
            }
        }

        if ($this->driverModel->update($id, $data)) {
             return redirect()->to('/drivers')->with('success', 'Driver updated successfully.');
        }

        return redirect()->back()->withInput()->with('errors', $this->driverModel->errors());
    }

    public function delete($id)
    {
        if ($this->driverModel->delete($id)) {
            return redirect()->to('/drivers')->with('success', 'Driver deleted successfully.');
        }
        return redirect()->to('/drivers')->with('error', 'Failed to delete driver.');
    }

    public function updateDocStatus()
    {
        $id = $this->request->getPost('driver_id');
        $field = $this->request->getPost('doc_field'); // e.g., 'doc_license_front_status'
        $status = $this->request->getPost('status');

        if (!$id || !$field || !$status) {
            return $this->response->setJSON(['success' => false, 'message' => 'Invalid data']);
        }

        // Validate field name to prevent arbitrary column updates
        $allowedFields = ['doc_license_front_status', 'doc_license_back_status', 'doc_id_proof_status'];
        if (!in_array($field, $allowedFields)) {
             return $this->response->setJSON(['success' => false, 'message' => 'Invalid document field']);
        }

        if ($this->driverModel->update($id, [$field => $status])) {
            return $this->response->setJSON(['success' => true]);
        }

        return $this->response->setJSON(['success' => false, 'message' => 'Failed to update']);
    }
}
