<?= $this->extend('layouts/master') ?>

<?= $this->section('content') ?>

<div style="padding: 2rem; max-width: 1400px; margin: 0 auto;">
    
    <div style="margin-bottom: 2rem; display: flex; justify-content: space-between; align-items: center;">
        <div>
            <h1 class="h3" style="margin:0;">Dashboard</h1>
            <div style="color:var(--text-secondary); font-size:0.9rem;">Overview of your dispatch operations</div>
        </div>
        <div>
            <span style="font-size:0.85rem; color:var(--text-secondary); background:var(--bg-surface); padding:0.5rem 1rem; border-radius:var(--radius-sm); border:1px solid var(--border-color);">
                <?= date('l, F j, Y') ?>
            </span>
        </div>
    </div>

    <!-- Metrics Grid -->
    <div class="metrics-grid">
        
        <!-- Active Trips -->
        <div class="metric-card">
            <div class="icon-box" style="background: rgba(99, 102, 241, 0.1); color: var(--primary);">
                <i data-lucide="activity" width="20"></i>
            </div>
            <div>
                <div class="metric-value"><?= $metrics['active_trips'] ?></div>
                <div class="metric-label">Active Trips</div>
            </div>
        </div>

        <!-- Pending Requests -->
        <div class="metric-card">
            <div class="icon-box" style="background: rgba(245, 158, 11, 0.1); color: var(--warning);">
                <i data-lucide="clock" width="20"></i>
            </div>
            <div>
                <div class="metric-value"><?= $metrics['pending_requests'] ?></div>
                <div class="metric-label">Pending Requests</div>
            </div>
        </div>

        <!-- Online Drivers -->
        <div class="metric-card">
            <div class="icon-box" style="background: rgba(16, 185, 129, 0.1); color: var(--success);">
                <i data-lucide="car" width="20"></i>
            </div>
            <div>
                <div class="metric-value"><?= $metrics['online_drivers'] ?> <span style="font-size:0.8rem; font-weight:400; color:var(--text-secondary);">/ <?= $metrics['total_drivers'] ?></span></div>
                <div class="metric-label">Drivers Online</div>
            </div>
        </div>

        <!-- Total Revenue -->
        <div class="metric-card">
            <div class="icon-box" style="background: rgba(14, 165, 233, 0.1); color: var(--info);">
                <i data-lucide="dollar-sign" width="20"></i>
            </div>
            <div>
                <div class="metric-value">$<?= number_format($metrics['total_revenue'], 2) ?></div>
                <div class="metric-label">Total Revenue</div>
            </div>
        </div>

    </div>

    <div style="display:grid; grid-template-columns: 2fr 1fr; gap:2rem; margin-top:2rem;">
        
        <!-- Chart Section -->
        <div class="card" style="padding:1.5rem; height:400px; display:flex; flex-direction:column;">
            <h3 class="form-section-title" style="margin-bottom:1rem; font-size:1rem;">Trips Overview (Last 7 Days)</h3>
            <div style="flex:1; position:relative;">
                <canvas id="tripsChart"></canvas>
            </div>
        </div>

        <!-- Recent Activity -->
        <div class="card" style="padding:0; display:flex; flex-direction:column; max-height:400px; overflow:hidden;">
            <div style="padding:1rem 1.5rem; border-bottom:1px solid var(--border-color);">
                <h3 class="form-section-title" style="margin:0; font-size:1rem; border:none; padding:0;">Recent Trips</h3>
            </div>
            <div style="overflow-y:auto; padding:0;">
                <?php if(empty($recent_trips)): ?>
                    <div style="padding:2rem; text-align:center; color:var(--text-secondary);">No recent activity</div>
                <?php else: ?>
                    <?php foreach($recent_trips as $trip): ?>
                    <a href="<?= base_url('dispatch/trips/edit/'.$trip->id) ?>" style="display:block; padding:1rem 1.5rem; border-bottom:1px solid var(--border-color); transition:background 0.1s; text-decoration:none;">
                        <div style="display:flex; justify-content:space-between; align-items:flex-start; margin-bottom:4px;">
                            <span class="status-badge status-<?= $trip->status ?>" style="font-size:0.7rem;"><?= ucfirst($trip->status) ?></span>
                            <span style="font-size:0.75rem; color:var(--text-secondary);"><?= date('M j, H:i', strtotime($trip->created_at)) ?></span>
                        </div>
                        <div style="font-weight:600; font-size:0.9rem; color:var(--text-primary);">
                             #<?= $trip->trip_number ?>
                        </div>
                        <div style="font-size:0.8rem; color:var(--text-secondary); display:flex; align-items:center; gap:6px; margin-top:4px;">
                             <i data-lucide="map-pin" width="12"></i> <?= substr($trip->pickup_address, 0, 30) ?>...
                        </div>
                    </a>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
            <div style="padding:1rem; border-top:1px solid var(--border-color); text-align:center;">
                <a href="<?= base_url('dispatch/trips') ?>" style="font-size:0.85rem; font-weight:600; color:var(--primary);">View All Trips</a>
            </div>
        </div>

    </div>

</div>

<style>
    .metrics-grid {
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        gap: 1.5rem;
    }
    .metric-card {
        background: var(--bg-surface);
        border: 1px solid var(--border-color);
        border-radius: var(--radius-md);
        padding: 1.5rem;
        display: flex;
        align-items: center;
        gap: 1.5rem;
    }
    .icon-box {
        width: 48px;
        height: 48px;
        border-radius: 12px;
        display: flex;
        align-items: center;
        justify-content: center;
    }
    .metric-value {
        font-size: 1.5rem;
        font-weight: 700;
        color: var(--text-primary);
        line-height: 1.2;
    }
    .metric-label {
        font-size: 0.85rem;
        color: var(--text-secondary);
        font-weight: 500;
    }
    @media (max-width: 1024px) {
        .metrics-grid { grid-template-columns: repeat(2, 1fr); }
    }
    @media (max-width: 640px) {
        .metrics-grid { grid-template-columns: 1fr; }
    }
</style>

<!-- Chart.js via CDN for Quick Win -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        const ctx = document.getElementById('tripsChart').getContext('2d');
        const chartData = <?= json_encode($chart_data) ?>;
        
        // Prepare labels and data
        const labels = chartData.map(item => {
            const date = new Date(item.date);
            return date.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' });
        });
        const dataPoints = chartData.map(item => item.count);

        new Chart(ctx, {
            type: 'line',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Trips',
                    data: dataPoints,
                    borderColor: '#6366f1',
                    backgroundColor: 'rgba(99, 102, 241, 0.1)',
                    borderWidth: 2,
                    tension: 0.4,
                    fill: true,
                    pointBackgroundColor: '#6366f1'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        grid: { color: 'rgba(255, 255, 255, 0.05)' },
                        ticks: { color: '#94a3b8' }
                    },
                    x: {
                        grid: { display: false },
                        ticks: { color: '#94a3b8' }
                    }
                }
            }
        });
    });
</script>

<?= $this->endSection() ?>
