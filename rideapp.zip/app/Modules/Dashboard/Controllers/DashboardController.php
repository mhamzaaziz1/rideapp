<?php

namespace Modules\Dashboard\Controllers;

use App\Controllers\BaseController;
use Modules\Dispatch\Models\TripModel;
use Modules\Fleet\Models\DriverModel;
use Modules\Customer\Models\CustomerModel;

class DashboardController extends BaseController
{
    public function index()
    {
        $tripModel = new TripModel();
        $driverModel = new DriverModel();
        $customerModel = new CustomerModel();

        // 1. Key Metrics
        $totalTrips = $tripModel->countAllResults();
        $activeTrips = $tripModel->whereIn('status', ['active', 'dispatching'])->countAllResults();
        $pendingRequests = $tripModel->where('status', 'pending')->countAllResults();
        
        $totalDrivers = $driverModel->countAllResults();
        $onlineDrivers = $driverModel->where('status', 'active')->countAllResults(); // Assuming 'active' means online/available for now
        
        $totalCustomers = $customerModel->where('deleted_at', null)->countAllResults();
        
        // Revenue (Mock calculation or sum if fare_amount exists)
        // For now, let's sum 'fare_amount' of completed trips
        $revenue = $tripModel->where('status', 'completed')->selectSum('fare_amount')->get()->getRow()->fare_amount ?? 0;

        // 2. Recent Activity (Last 5 trips)
        $recentTrips = $tripModel->orderBy('created_at', 'DESC')->limit(5)->find();

        // 3. Chart Data (Trips last 7 days)
        // Mocking this for simplicity, or we can run a query
        $db = \Config\Database::connect();
        $query = $db->query("
            SELECT DATE(created_at) as date, COUNT(*) as count 
            FROM trips 
            WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY) 
            GROUP BY DATE(created_at) 
            ORDER BY DATE(created_at) ASC
        ");
        $chartData = $query->getResultArray();

        $data = [
            'metrics' => [
                'active_trips' => $activeTrips,
                'pending_requests' => $pendingRequests,
                'online_drivers' => $onlineDrivers,
                'total_drivers' => $totalDrivers,
                'total_customers' => $totalCustomers,
                'total_revenue' => $revenue
            ],
            'recent_trips' => $recentTrips,
            'chart_data' => $chartData,
            'title' => 'Dashboard'
        ];

        return view('Modules\Dashboard\Views\dashboard\index', $data);
    }
}
