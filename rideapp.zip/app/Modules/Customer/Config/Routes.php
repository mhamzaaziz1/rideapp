<?php

namespace Modules\Customer\Config;

use Config\Services;

$routes = Services::routes();

$routes->group('customers', ['namespace' => 'Modules\Customer\Controllers'], function ($routes) {
    $routes->get('/', 'CustomerController::index');
    $routes->get('create', 'CustomerController::new');
    $routes->get('new', 'CustomerController::new');
    $routes->post('create', 'CustomerController::create');
    $routes->get('edit/(:num)', 'CustomerController::edit/$1');
    $routes->post('update/(:num)', 'CustomerController::update/$1');
    $routes->get('delete/(:num)', 'CustomerController::delete/$1');
    $routes->post('update_status', 'CustomerController::updateStatus');
    $routes->get('profile/(:num)', 'CustomerController::profile/$1');
});

// Explicit global get for robustness
$routes->get('customers', 'CustomerController::index', ['namespace' => 'Modules\Customer\Controllers']);
