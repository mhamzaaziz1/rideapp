<?= $this->extend('layouts/master') ?>

<?= $this->section('content') ?>

<style>
    /* Profile Header */
    .profile-header {
        background: var(--bg-surface);
        border: 1px solid var(--border-color);
        border-radius: var(--radius-md);
        padding: 2.5rem;
        margin-bottom: 2rem;
        display: flex;
        justify-content: space-between;
        align-items: center;
        position: relative;
        overflow: hidden;
    }
    .profile-header::before {
        content: ''; position: absolute; top:0; left:0; width:100%; height:6px; background:linear-gradient(90deg, var(--primary), var(--info));
    }
    
    .profile-info { display: flex; align-items: center; gap: 2rem; }
    .profile-avatar {
        width: 100px; height: 100px;
        border-radius: 50%;
        background: var(--bg-surface-hover);
        border: 4px solid var(--bg-body);
        box-shadow: 0 0 0 1px var(--border-color);
        display: flex; align-items: center; justify-content: center;
        font-size: 2.5rem; font-weight: 700; color: var(--text-secondary);
        overflow: hidden;
    }
    .profile-name { font-size: 1.75rem; font-weight: 700; color: var(--text-primary); margin-bottom: 0.25rem; }
    .profile-meta { font-size: 0.95rem; color: var(--text-secondary); display: flex; gap: 1.5rem; align-items: center; }
    .profile-meta span { display: flex; align-items: center; gap: 6px; }

    /* Stats Grid */
    .profile-stats {
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        gap: 1.5rem;
        margin-bottom: 2rem;
    }
    .p-stat-card {
        background: var(--bg-surface);
        border: 1px solid var(--border-color);
        border-radius: var(--radius-md);
        padding: 1.5rem;
        text-align: center;
    }
    .p-stat-val { font-size: 1.5rem; font-weight: 700; color: var(--text-primary); margin-bottom: 0.25rem; }
    .p-stat-label { font-size: 0.8rem; color: var(--text-secondary); text-transform: uppercase; letter-spacing: 0.05em; }

    /* Tabs */
    .profile-tabs {
        border-bottom: 1px solid var(--border-color);
        margin-bottom: 1.5rem;
        display: flex; gap: 2rem;
    }
    .p-tab {
        padding-bottom: 1rem;
        font-weight: 600;
        color: var(--text-secondary);
        cursor: pointer;
        border-bottom: 2px solid transparent;
        transition: all 0.2s;
    }
    .p-tab:hover { color: var(--text-primary); }
    .p-tab.active { color: var(--primary); border-bottom-color: var(--primary); }

    /* Trip History List (Reuse styling from dispatch or simplify) */
    .history-item {
        background: var(--bg-surface);
        border: 1px solid var(--border-color);
        border-radius: var(--radius-sm);
        padding: 1.25rem;
        margin-bottom: 1rem;
        display: flex; align-items: center; justify-content: space-between;
    }
    .history-route { display: flex; align-items: center; gap: 1rem; flex: 1; margin: 0 2rem; }
    .route-arrow { color: var(--text-secondary); }
</style>

<div style="padding: 2rem; max-width: 1200px; margin: 0 auto;">
    
    <!-- Breadcrumb -->
    <div style="margin-bottom: 1.5rem;">
        <a href="<?= base_url('customers') ?>" style="color:var(--text-secondary); display:inline-flex; align-items:center; gap:4px; font-size:0.9rem;">
            <i data-lucide="arrow-left" width="16"></i> Back to Customers
        </a>
    </div>

    <!-- Header -->
    <div class="profile-header">
        <div class="profile-info">
            <div class="profile-avatar">
                <?php if($customer->avatar): ?>
                    <img src="<?= base_url($customer->avatar) ?>" style="width:100%; height:100%; object-fit:cover;">
                <?php else: ?>
                    <?= substr($customer->first_name, 0, 1) . substr($customer->last_name, 0, 1) ?>
                <?php endif; ?>
            </div>
            <div>
                <div class="profile-name"><?= esc($customer->first_name . ' ' . $customer->last_name) ?></div>
                <div class="profile-meta">
                    <span><i data-lucide="mail" width="16"></i> <?= esc($customer->email) ?></span>
                    <span><i data-lucide="phone" width="16"></i> <?= esc($customer->phone) ?></span>
                    <span class="status-badge status-<?= $customer->status ?>"><?= ucfirst($customer->status) ?></span>
                </div>
            </div>
        </div>
        <div style="display:flex; gap:1rem;">
            <a href="<?= base_url('customers/edit/'.$customer->id) ?>" class="btn btn-outline"><i data-lucide="edit-2" width="16" style="margin-right:6px"></i> Edit Profile</a>
            <?php if($customer->status == 'active'): ?>
                <button onclick="toggleStatus('inactive')" class="btn btn-outline" style="color:var(--danger); border-color:var(--danger);">Deactivate</button>
            <?php else: ?>
                <button onclick="toggleStatus('active')" class="btn btn-primary">Activate</button>
            <?php endif; ?>
        </div>
    </div>

    <!-- Stats -->
    <div class="profile-stats">
        <div class="p-stat-card">
            <div class="p-stat-val">$<?= number_format($real_total_spent, 2) ?></div>
            <div class="p-stat-label">Total Spent</div>
        </div>
        <div class="p-stat-card">
            <div class="p-stat-val"><?= count($trips) ?></div>
            <div class="p-stat-label">Total Trips</div>
        </div>
        <div class="p-stat-card">
            <div class="p-stat-val" style="display:flex; align-items:center; justify-content:center; gap:4px;">
                5.0 <i data-lucide="star" width="18" fill="var(--warning)" style="color:var(--warning)"></i>
            </div>
            <div class="p-stat-label">Rating</div>
        </div>
        <div class="p-stat-card">
            <div class="p-stat-val"><?= date('M Y', strtotime($customer->created_at)) ?></div>
            <div class="p-stat-label">Member Since</div>
        </div>
    </div>

    <!-- Content -->
    <div>
        <div class="profile-tabs">
            <div class="p-tab active">Trip History</div>
            <!-- <div class="p-tab">Notes</div> -->
            <!-- <div class="p-tab">Transactions</div> -->
        </div>

        <div id="tab-trips">
            <?php if(empty($trips)): ?>
                <div style="text-align:center; padding:3rem; color:var(--text-secondary); background:var(--bg-surface); border:1px dashed var(--border-color); border-radius:var(--radius-md);">
                    <i data-lucide="map" width="48" style="opacity:0.2; margin-bottom:1rem;"></i>
                    <p>No trips found for this customer.</p>
                </div>
            <?php else: ?>
                <?php foreach($trips as $t): ?>
                <div class="history-item">
                    <!-- Date & ID -->
                    <div>
                        <div style="font-weight:700; color:var(--primary); font-family:monospace;">#<?= $t->trip_number ?></div>
                        <div style="font-size:0.8rem; color:var(--text-secondary);"><?= date('M d, Y H:i', strtotime($t->created_at)) ?></div>
                    </div>
                    
                    <!-- Route -->
                    <div class="history-route">
                        <div style="width:40%;">
                            <div style="font-size:0.75rem; text-transform:uppercase; color:var(--text-secondary); margin-bottom:2px;">Pickup</div>
                            <div style="font-weight:500; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;" title="<?= esc($t->pickup_address) ?>"><?= esc($t->pickup_address) ?></div>
                        </div>
                        <div class="route-arrow"><i data-lucide="arrow-right"></i></div>
                        <div style="width:40%;">
                            <div style="font-size:0.75rem; text-transform:uppercase; color:var(--text-secondary); margin-bottom:2px;">Dropoff</div>
                            <div style="font-weight:500; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;" title="<?= esc($t->dropoff_address) ?>"><?= esc($t->dropoff_address) ?></div>
                        </div>
                    </div>

                    <!-- Meta -->
                    <div style="text-align:right; min-width:150px;">
                        <div style="font-weight:700; font-size:1.1rem;">$<?= number_format($t->fare_amount, 2) ?></div>
                        <div style="display:flex; align-items:center; justify-content:flex-end; gap:6px; margin-top:4px;">
                            <span class="status-badge status-<?= $t->status ?>" style="font-size:0.7rem;"><?= ucfirst($t->status) ?></span>
                            <?php if($t->d_first): ?>
                                <span title="Driver: <?= esc($t->d_first) ?>" style="font-size:0.8rem; color:var(--text-secondary); display:flex; align-items:center; gap:4px;"><i data-lucide="car" width="12"></i> <?= esc($t->d_first) ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>

</div>

<script>
    function toggleStatus(newStatus) {
        if(!confirm('Are you sure you want to change status to ' + newStatus + '?')) return;
        
        // Use existing updatedStatus endpoint
        const formData = new FormData();
        formData.append('id', <?= $customer->id ?>);
        formData.append('status', newStatus);
        
        fetch('<?= base_url("customers/update_status") ?>', {
            method: 'POST',
            body: formData
        })
        .then(r => r.json())
        .then(data => {
            if(data.success) location.reload();
            else alert('Failed to update status');
        });
    }
</script>

<?= $this->endSection() ?>
