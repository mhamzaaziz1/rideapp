<?php

namespace Modules\Dispatch\Controllers;

use App\Controllers\BaseController;
use Modules\Dispatch\Models\TripModel;
use Modules\Dispatch\Entities\Trip;

class TripController extends BaseController
{
    protected $tripModel;

    public function __construct()
    {
        $this->tripModel = new TripModel();
    }

    /**
     * API Endpoint to create a new trip from the Dashboard
     */
    public function create()
    {
        $data = $this->request->getJSON(true) ?? $this->request->getPost();
        
        $trip = new Trip($data);
        $trip->generateTripNumber();
        $trip->status = 'pending'; // Default status
        $trip->fare_amount = 51.25; // Hardcoded mock price for now
        $trip->distance_miles = 18.5; 
        
        // Mock Lat/Lng if not provided (New York area)
        if (empty($data['pickup_lat'])) {
            $trip->pickup_lat = 40.7128; // NY
            $trip->pickup_lng = -74.0060;
            $trip->dropoff_lat = 40.6413; // JFK
            $trip->dropoff_lng = -73.7781;
        }

        if ($this->tripModel->save($trip)) {
             if ($this->request->isAJAX() || $this->request->header('Content-Type') == 'application/json') {
                 return $this->response->setJSON([
                    'status' => 'success',
                    'message' => 'Trip created successfully',
                    'trip_number' => $trip->trip_number,
                    'trip_id' => $this->tripModel->getInsertID()
                 ]);
             }
             return redirect()->to('/dispatch')->with('success', 'Trip dispatched successfully: ' . $trip->trip_number);
        }

        if ($this->request->isAJAX()) {
             return $this->response->setJSON([
                'status' => 'error',
                'errors' => $this->tripModel->errors()
             ])->setStatusCode(400);
        }
        
        return redirect()->back()->withInput()->with('errors', $this->tripModel->errors());
    }

    public function new()
    {
        $customerModel = new \Modules\Customer\Models\CustomerModel();
        $driverModel = new \Modules\Fleet\Models\DriverModel();

        $data = [
            'trip' => new Trip(),
            'customers' => $customerModel->where('status', 'active')->findAll(),
            'drivers' => $driverModel->where('status', 'active')->findAll(),
            'title' => 'Create New Trip'
        ];
        return view('Modules\Dispatch\Views\trips\form', $data);
    }

    public function edit($id)
    {
        $trip = $this->tripModel->find($id);
        if (!$trip) {
            return redirect()->to('/dispatch/trips')->with('error', 'Trip not found');
        }

        $customerModel = new \Modules\Customer\Models\CustomerModel();
        $driverModel = new \Modules\Fleet\Models\DriverModel();

        $data = [
            'trip' => $trip,
            'customers' => $customerModel->findAll(), // Show all, even if inactive, for historical editing
            'drivers' => $driverModel->findAll(),
            'title' => 'Edit Trip #' . $trip->trip_number
        ];
        return view('Modules\Dispatch\Views\trips\form', $data);
    }

    public function update($id)
    {
        $trip = $this->tripModel->find($id);
        if (!$trip) {
            return redirect()->to('/dispatch/trips')->with('error', 'Trip not found');
        }

        // Check if this is a Quick Assign (partial update)
        if (!isset($data['pickup_address'])) {
            $rules = [
                'driver_id' => 'required',
                'status' => 'required'
            ];
        } else {
             $rules = [
                'customer_id' => 'required',
                'pickup_address' => 'required',
                'dropoff_address' => 'required',
                'status' => 'required'
            ];
        }

        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        $data = $this->request->getPost();
        
        // Handle Driver Assignment Logic (simple for now)
        if (!empty($data['driver_id']) && $data['driver_id'] != $trip->driver_id) {
             // Logic to notify driver could go here
        }

        if (!$this->tripModel->update($id, $data)) {
            return redirect()->back()->withInput()->with('error', 'Failed to update trip');
        }

        return redirect()->to('/dispatch/trips')->with('success', 'Trip updated successfully');
    }

    public function delete($id)
    {
        if ($this->tripModel->delete($id)) {
            return redirect()->to('/dispatch/trips')->with('success', 'Trip deleted successfully');
        }
        return redirect()->to('/dispatch/trips')->with('error', 'Failed to delete trip');
    }

    public function updateStatus()
    {
        $id = $this->request->getPost('id');
        $status = $this->request->getPost('status');

        if (!$id || !$status) {
            return $this->response->setJSON(['success' => false, 'message' => 'Invalid data']);
        }

        if ($this->tripModel->update($id, ['status' => $status])) {
             return $this->response->setJSON(['success' => true]);
        }

        return $this->response->setJSON(['success' => false, 'message' => 'Failed to update status']);
    }

    public function index()
    {
        // 1. Fetch All Trips with Joins
        $builder = $this->tripModel->builder();
        $builder->select('trips.*, customers.first_name as c_first, customers.last_name as c_last, drivers.first_name as d_first, drivers.last_name as d_last, drivers.vehicle_model');
        $builder->join('customers', 'customers.id = trips.customer_id', 'left');
        $builder->join('drivers', 'drivers.id = trips.driver_id', 'left');
        $builder->where('trips.deleted_at', null);
        $builder->orderBy('trips.created_at', 'DESC');
        
        $allTrips = $builder->get()->getResult();

        // 2. bucket them
        $queue = [];
        $active = [];
        $history = [];

        foreach ($allTrips as $t) {
            if (in_array($t->status, ['completed', 'cancelled'])) {
                $history[] = $t;
            } elseif (in_array($t->status, ['active', 'dispatching'])) {
                $active[] = $t;
            } else {
                // Pending, or any other status goes to queue
                $queue[] = $t;
            }
        }

        // Fetch drivers for sidebar/modal
        $driverModel = new \Modules\Fleet\Models\DriverModel();
        $availableDrivers = $driverModel->where('status', 'active')->findAll();

        // Fetch customers for Quick Dispatch Modal
        $customerModel = new \Modules\Customer\Models\CustomerModel();
        $allCustomers = $customerModel->where('deleted_at', null)->orderBy('first_name', 'ASC')->findAll();

        $data = [
            'trips_queue' => $queue,
            'trips_active' => $active,
            'trips_history' => $history,
            'drivers' => $availableDrivers,
            'customers' => $allCustomers,
            'active_tab' => 'queue', // Default
            
            // Keep stats for the top bar
            'total_trips' => count($allTrips),
            'in_progress' => count($active),
            'completed' => count($history), // roughly
            'revenue' => $this->tripModel->selectSum('fare_amount')->first()->fare_amount ?? 0,
            'title' => 'Dispatch Board'
        ];
        
        return view('Modules\Dispatch\Views\trips\index', $data);
    }
}
