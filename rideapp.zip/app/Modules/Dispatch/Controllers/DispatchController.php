<?php

namespace Modules\Dispatch\Controllers;

use App\Controllers\BaseController;

class DispatchController extends BaseController
{
    public function index()
    {
        return view('Modules\Dispatch\Views\dashboard', [
            'title' => 'Dispatch Console'
        ]);
    }
}
