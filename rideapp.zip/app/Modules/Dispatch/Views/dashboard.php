<?= $this->extend('layouts/master') ?>

<?= $this->section('content') ?>

<style>
    /* Dashboard Specific Styles matching the Mockup */
    .dashboard-container {
        display: flex;
        flex-direction: column;
        height: 100%;
        background-color: var(--bg-body);
    }
    
    /* Stats Row */
    .stats-bar {
        background-color: var(--bg-surface);
        padding: 0.75rem 1.5rem;
        border-bottom: 1px solid var(--border-color);
        display: flex;
        align-items: center;
        gap: 2rem;
        font-size: 0.85rem;
        color: var(--text-secondary);
    }
    .stat-item { display: flex; align-items: center; gap: 0.5rem; }
    .stat-val { font-weight: 600; color: var(--text-primary); }
    .stat-icon { width: 16px; height: 16px; }

    /* Main Grid */
    .dashboard-grid {
        flex: 1;
        display: grid;
        grid-template-columns: 260px 280px 1fr 320px 240px; /* 5 Columns */
        gap: 1rem;
        padding: 1rem;
        overflow: hidden; /* Individual cols scroll */
    }



    .route-map-placeholder {
        width: 100%;
        height: 100%;
        background: url('https://upload.wikimedia.org/wikipedia/commons/e/ec/World_map_blank_without_borders.svg') no-repeat center center;
        background-size: cover;
        opacity: 0.5;
        position: relative;
    }

    /* Form Styles */
    .form-group { margin-bottom: 1rem; }
    .form-label { display: block; font-size: 0.75rem; color: var(--text-secondary); margin-bottom: 0.25rem; text-transform: uppercase; letter-spacing: 0.05em; }
    .form-input { width: 100%; background: var(--bg-body); border: 1px solid var(--border-color); padding: 0.5rem; border-radius: 6px; color: var(--text-primary); }
    
    /* Trip Details */
    .trip-price-box {
        background: rgba(99, 102, 241, 0.1);
        padding: 1rem;
        border-radius: 8px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-top: auto;
    }
    .price-lg { font-size: 1.25rem; font-weight: 700; color: var(--primary-hover); }

</style>

<div class="dashboard-container">
    <!-- Stats Row -->
    <div class="stats-bar">
        <div class="stat-item"><i data-lucide="phone" class="stat-icon text-primary"></i> <span class="stat-val">120</span> call</div>
        <div class="stat-item"><i data-lucide="check-circle" class="stat-icon" style="color:var(--success)"></i> <span class="stat-val">101</span> accepted</div>
        <div class="stat-item"><i data-lucide="x-circle" class="stat-icon" style="color:var(--danger)"></i> <span class="stat-val">12</span> dropped</div>
        <div class="stat-item"><i data-lucide="slash" class="stat-icon" style="color:var(--warning)"></i> <span class="stat-val">7</span> no trip</div>
        <div class="stat-item"><i data-lucide="navigation" class="stat-icon" style="color:var(--info)"></i> <span class="stat-val">3</span> ongoing</div>
        <div style="flex:1"></div>
        <div class="stat-item" id="btn-hourly-stats" style="cursor:pointer; transition:color 0.2s;"><i data-lucide="clock" class="stat-icon"></i> Hourly Stats</div>
    </div>

    <div class="dashboard-grid">
        
        <!-- COL 1: Live Status -->
        <div style="display:flex; flex-direction:column; gap:1rem; overflow:hidden;">
            <!-- Live Panel -->
            <div class="col-panel" style="flex:1">
                <div class="panel-header"><i data-lucide="navigation" width="16"></i> Live <span class="badge" style="margin-left:auto">3</span></div>
                <div class="panel-body">
                     <div style="font-size:0.85rem; margin-bottom:1rem;">
                        <div style="color:var(--info); font-weight:600;">TRP-881251</div>
                        <div>Robert Smith</div>
                        <div style="color:var(--text-secondary); font-size:0.75rem;">ETA: 12 min • $52</div>
                     </div>
                     <div style="font-size:0.85rem;">
                        <div style="color:var(--warning); font-weight:600;">TRP-881252</div>
                        <div>Maria Garcia</div>
                        <div style="color:var(--text-secondary); font-size:0.75rem;">At Pickup • $35</div>
                     </div>
                </div>
            </div>
        </div>

        <!-- COL 2: Customer -->
        <div class="col-panel">
            <div class="panel-header"><i data-lucide="user" width="16"></i> Customer</div>
            <div class="panel-body">
                <div style="display:flex; align-items:center; gap:10px; margin-bottom:1.5rem;">
                    <div style="width:40px; height:40px; background:var(--primary); border-radius:50%; display:flex; align-items:center; justify-content:center; color:white; font-weight:700;">JD</div>
                    <div>
                        <div style="font-weight:600;">John Doe <span class="badge" style="background:gold; color:black; padding:0 4px; font-size:0.6rem;">VIP</span></div>
                        <div style="font-size:0.8rem; color:var(--text-secondary);">+1 (555) 123-4567</div>
                    </div>
                </div>

                <div style="display:flex; flex-direction:column; gap:0.75rem; font-size:0.85rem;">
                    <div style="display:flex; gap:8px; color:var(--text-secondary);"><i data-lucide="mail" width="14"></i> john@email.com</div>
                    <div style="display:flex; gap:8px; color:var(--text-secondary);"><i data-lucide="map-pin" width="14"></i> 123 Main St, NY</div>
                    <div style="display:flex; gap:8px;"><i data-lucide="history" width="14"></i> 24 trips</div>
                    <div style="display:flex; gap:8px; color:var(--success);"><i data-lucide="dollar-sign" width="14"></i> $150</div>
                </div>

                <div style="margin-top:1.5rem; font-size:0.8rem; color:var(--text-secondary); font-style:italic;">
                    Prefers sedan, always tips well.
                </div>
            </div>
        </div>

        <!-- COL 3: Trip Details (The Core Form) -->
        <div class="col-panel">
            <div class="panel-header"><i data-lucide="file-text" width="16"></i> Trip Details</div>
            <div class="panel-body" style="display:flex; flex-direction:column;">
                
                <div class="form-group">
                    <label class="form-label">Pickup</label>
                    <div style="position:relative">
                        <i data-lucide="map-pin" style="position:absolute; left:8px; top:8px; width:16px; color:var(--success)"></i>
                        <input type="text" class="form-input" value="123 Main St, New York, NY 10001" style="padding-left:30px">
                    </div>
                </div>

                <div class="form-group">
                    <label class="form-label">Dropoff</label>
                    <div style="position:relative">
                        <i data-lucide="map-pin" style="position:absolute; left:8px; top:8px; width:16px; color:var(--danger)"></i>
                        <input type="text" class="form-input" value="JFK Airport, Queens, NY" style="padding-left:30px">
                    </div>
                </div>

                <div style="display:grid; grid-template-columns:1fr 1fr; gap:1rem;">
                    <div class="form-group">
                        <label class="form-label">Date</label>
                        <input type="date" class="form-input" value="2026-02-03">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Time</label>
                        <input type="text" class="form-input" value="02:30 PM">
                    </div>
                </div>

                <div style="display:grid; grid-template-columns:1fr 1fr; gap:1rem;">
                    <div class="form-group">
                        <label class="form-label">Vehicle</label>
                        <select class="form-input"><option>Sedan</option><option>SUV</option></select>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Passengers</label>
                        <input type="number" class="form-input" value="2">
                    </div>
                </div>

                <div class="form-group">
                    <label class="form-label">Payment</label>
                    <div style="display:flex; align-items:center; gap:8px; background:var(--bg-body); border:1px solid var(--border-color); padding:0.5rem; border-radius:6px;">
                        <i data-lucide="credit-card" width="16"></i> Card <i data-lucide="chevron-down" width="14" style="margin-left:auto"></i>
                    </div>
                </div>

                <div class="form-group" style="flex:1">
                    <label class="form-label">Notes</label>
                    <textarea class="form-input" style="height:80px; resize:none;">Special instructions...</textarea>
                </div>

                <div class="trip-price-box">
                    <div>
                        <div style="font-size:0.75rem; color:var(--text-secondary);">18.5 mi | ~35 min</div>
                    </div>
                    <div class="price-lg">$51.25</div>
                </div>

                <button class="btn btn-primary" id="btn-dispatch" style="width:100%; margin-top:1rem; padding:0.75rem;">
                    <i data-lucide="send" width="16" style="margin-right:8px;"></i> Send to Drivers
                </button>

            </div>
        </div>

        <!-- COL 4: Route Map -->
        <div class="col-panel">
            <div class="panel-header">
                <i data-lucide="map" width="16"></i> Route Map
                <button class="btn btn-primary" style="padding:2px 8px; font-size:0.7rem; margin-left:auto;"><i data-lucide="traffic-cone" width="12"></i> Traffic</button>
            </div>
            <div class="panel-body" style="padding:0;">
                
                <!-- Leaflet CSS & JS -->
                <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" integrity="sha256-p4NxAoJBhIIN+hmNHrzRCf9tD/miZyoHS5obTRR9BMY=" crossorigin=""/>
                <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js" integrity="sha256-20nQCchB9co0qIjJZRGuk2/Z9VM+kNiyxNV1lvTlZBo=" crossorigin=""></script>
                
                <style>
                    #map { height: 100%; width: 100%; background: #f0f0f0; }
                    .leaflet-popup-content-wrapper { border-radius: 4px; font-size: 0.8rem; }
                    .leaflet-popup-content { margin: 8px; }
                </style>

                <div id="map" class="route-map-placeholder" style="background:none;"></div>

                <!-- Distance/Time Stats below map -->
                <div style="padding:1rem; display:grid; grid-template-columns:1fr 1fr 1fr; gap:0.5rem; text-align:center;">
                    <div>
                        <div style="font-weight:700;">18.5 mi</div>
                        <div style="font-size:0.7rem; color:var(--text-secondary);">Distance</div>
                    </div>
                    <div>
                        <div style="font-weight:700;">35 min</div>
                        <div style="font-size:0.7rem; color:var(--text-secondary);">Duration</div>
                    </div>
                    <div style="background:rgba(245, 158, 11, 0.1); color:var(--warning); border-radius:4px; padding:2px;">
                        <div style="font-weight:700;">Moderate</div>
                        <div style="font-size:0.7rem;">Traffic</div>
                    </div>
                </div>
            </div>
        </div>

        <!-- COL 5: Drivers -->
        <div class="col-panel">
            <div class="panel-header"><i data-lucide="car" width="16"></i> Drivers</div>
            <div class="panel-body" style="display:flex; align-items:center; justify-content:center; flex-direction:column; color:var(--text-secondary); text-align:center;">
                <i data-lucide="users" width="48" style="opacity:0.2; margin-bottom:1rem;"></i>
                <p style="font-size:0.85rem;">Enter trip details and dispatch</p>
                <small>4 drivers online</small>
            </div>
        </div>

    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', () => {
        lucide.createIcons();

        // --- Hourly Stats Modal Logic ---
        const modal = document.getElementById('hourlyStatsModal');
        const btn = document.getElementById('btn-hourly-stats');
        const closeBtn = document.querySelector('.close-modal');

        if(btn) {
            btn.addEventListener('mouseenter', () => btn.style.color = 'var(--primary)');
            btn.addEventListener('mouseleave', () => btn.style.color = '');
            
            btn.addEventListener('click', () => {
                modal.style.display = 'flex';
                // Trigger animation
                setTimeout(() => {
                    modal.querySelector('.modal-content').style.transform = 'scale(1)';
                    modal.querySelector('.modal-content').style.opacity = '1';
                }, 10);
            });
        }

        if(closeBtn) {
            closeBtn.addEventListener('click', () => {
                modal.querySelector('.modal-content').style.transform = 'scale(0.95)';
                modal.querySelector('.modal-content').style.opacity = '0';
                setTimeout(() => modal.style.display = 'none', 200);
            });
        }

        // Close on click outside
        window.onclick = function(event) {
            if (event.target == modal) {
                modal.querySelector('.modal-content').style.transform = 'scale(0.95)';
                modal.querySelector('.modal-content').style.opacity = '0';
                setTimeout(() => modal.style.display = 'none', 200);
            }
        }

        // --- Leaflet Map Init ---
        const map = L.map('map', { zoomControl: false }).setView([40.69, -73.9], 11);
        
        L.tileLayer('https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png', {
            attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>',
            subdomains: 'abcd',
            maxZoom: 20
        }).addTo(map);

        // Custom Icons
        const pickupIcon = L.divIcon({
            html: '<div style="background:var(--success); width:12px; height:12px; border-radius:50%; border:2px solid white; box-shadow:0 2px 4px rgba(0,0,0,0.3);"></div>',
            className: 'custom-div-icon',
            iconSize: [12, 12],
            iconAnchor: [6, 6]
        });

        const dropoffIcon = L.divIcon({
            html: '<div style="background:var(--danger); width:12px; height:12px; border-radius:50%; border:2px solid white; box-shadow:0 2px 4px rgba(0,0,0,0.3);"></div>',
            className: 'custom-div-icon',
            iconSize: [12, 12],
            iconAnchor: [6, 6]
        });

        // Markers: Pickup (Manhattan) & Dropoff (JFK)
        const pickupPos = [40.7128, -74.0060];
        const dropoffPos = [40.6413, -73.7781];

        L.marker(pickupPos, {icon: pickupIcon}).addTo(map).bindPopup("<b>Pickup:</b> 123 Main St");
        L.marker(dropoffPos, {icon: dropoffIcon}).addTo(map).bindPopup("<b>Dropoff:</b> JFK Airport");

        // Fit bounds
        const group = new L.featureGroup([L.marker(pickupPos), L.marker(dropoffPos)]);
        map.fitBounds(group.getBounds().pad(0.2));

        // Simple Polyline to simulate route
        L.polyline([pickupPos, dropoffPos], {
            color: 'var(--primary)',
            weight: 3,
            opacity: 0.7,
            dashArray: '5, 10'
        }).addTo(map);

        // --- End Leaflet Map Init ---

        // Trip Creation Logic
        const createTripBtn = document.querySelector('.btn-primary'); // The 'Send to Drivers' button (ensure it is the right one or use specific class)
        // Add a specific class to the button first to be safe, or select by text content if possible, but let's add a class in a separate edit or target it carefully.
        // Looking at the file, the specific button has "Send to Drivers" text.
        
        // Let's rely on the button inside the panel-body of the "Trip Details" column.
        const sendBtn = Array.from(document.querySelectorAll('button')).find(b => b.textContent.includes('Send to Drivers'));

        if(sendBtn) {
            sendBtn.addEventListener('click', async (e) => {
                e.preventDefault();
                
                // Gather form data - targeting inputs by their placeholders or nearby labels would be robust, but for now we rely on the order or structure matching the mockup.
                // We'll use more specific selectors based on the DOM structure we see.
                
                const inputs = document.querySelectorAll('.form-input');
                // input[0] = Pickup
                // input[1] = Dropoff
                // input[2] = Date
                // input[3] = Time
                // input[4] = Vehicle (select)
                // input[5] = Passengers
                // input[6] = Notes (textarea)
                
                const payload = {
                    pickup_address: inputs[0].value,
                    dropoff_address: inputs[1].value,
                    vehicle_type: inputs[4].value,
                    passengers: inputs[5].value,
                    notes: inputs[6].value,
                    // Mock coordinates
                    pickup_lat: 40.7128,
                    pickup_lng: -74.0060, 
                    dropoff_lat: 40.6413,
                    dropoff_lng: -73.7781
                };

                // Loading state
                const originalText = sendBtn.innerHTML;
                sendBtn.innerHTML = '<i data-lucide="loader-2" class="animate-spin" width="16"></i> Dispatching...';
                sendBtn.disabled = true;
                lucide.createIcons();

                try {
                    const response = await fetch('<?= base_url('dispatch/trips/create') ?>', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-Requested-With': 'XMLHttpRequest'
                        },
                        body: JSON.stringify(payload)
                    });

                    const result = await response.json();

                    if (response.ok) {
                        alert('Success! Trip dispatched.\nTrip Number: ' + result.trip_number);
                        // Optional: Clear form or redirect
                    } else {
                        alert('Error: ' + JSON.stringify(result.errors || result.message));
                    }
                } catch (error) {
                    console.error('Error:', error);
                    alert('Failed to dispatch trip.');
                } finally {
                     sendBtn.innerHTML = '<i data-lucide="check" width="16"></i> Sent';
                     setTimeout(() => {
                        sendBtn.innerHTML = originalText;
                        sendBtn.disabled = false;
                        lucide.createIcons();
                     }, 2000);
                }
            });
        }
    });
</script>

<?= $this->endSection() ?>
