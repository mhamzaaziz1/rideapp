<div class="trip-card">
    
    <!-- 1. Status Column -->
    <div style="text-align:center;">
        <span class="status-badge status-<?= $trip->status ?>" style="display:block; margin-bottom:4px; font-size:0.7rem;">
            <?= ucfirst($trip->status) ?>
        </span>
        <div style="font-family:monospace; font-weight:700; color:var(--text-primary); font-size:0.85rem;">
            #<?= $trip->trip_number ?>
        </div>
        <div style="font-size:0.75rem; color:var(--text-secondary); margin-top:2px;">
            <?= date('H:i', strtotime($trip->created_at)) ?>
        </div>
    </div>

    <!-- 2. Route Column -->
    <div class="route-visual">
        <div class="route-point">
            <div class="route-icon" style="background:var(--success);"></div>
            <div style="white-space:nowrap; overflow:hidden; text-overflow:ellipsis; font-weight:500;">
                <?= esc($trip->pickup_address) ?>
            </div>
        </div>
        <div class="route-point">
            <div class="route-icon" style="background:var(--danger);"></div>
            <div style="color:var(--text-secondary); white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">
                <?= esc($trip->dropoff_address) ?>
            </div>
        </div>
        <div style="margin-top:6px; font-size:0.75rem; color:var(--text-secondary); padding-left:22px;">
            <span style="margin-right:8px;"><i data-lucide="navigation" width="10" style="vertical-align:middle"></i> <?= $trip->distance_miles ?> mi</span>
            <span><i data-lucide="dollar-sign" width="10" style="vertical-align:middle"></i> $<?= number_format($trip->fare_amount, 2) ?></span>
        </div>
    </div>

    <!-- 3. Customer/Driver Info -->
    <div>
        <div style="font-weight:600; font-size:0.9rem; margin-bottom:2px;">
            <?= esc($trip->c_first ?? 'Guest') ?>
        </div>
        <div style="font-size:0.8rem; color:var(--text-secondary);">
            <?php if($trip->d_first): ?>
                <i data-lucide="car" width="12" style="vertical-align:text-bottom"></i> <?= esc($trip->d_first) ?>
            <?php else: ?>
                <span style="color:var(--warning);">Unassigned</span>
            <?php endif; ?>
        </div>
    </div>

    <!-- 4. Action Column -->
    <div style="text-align:right;">
        <?php if($type == 'queue' && !$trip->driver_id): ?>
            <button onclick="openAssignModal(<?= $trip->id ?>)" class="btn-xs btn-primary" style="width:100%; margin-bottom:4px;">Assign</button>
        <?php else: ?>
            <a href="<?= base_url('dispatch/trips/edit/'.$trip->id) ?>" class="btn-xs btn-outline" style="width:100%; margin-bottom:4px; text-align:center; display:block;">Details</a>
        <?php endif; ?>
    </div>

</div>

<style>
    .btn-xs { 
        padding: 4px 8px; font-size: 0.75rem; border-radius: 4px; border:none; cursor:pointer; font-weight:600; text-decoration:none;
    }
    .btn-xs.btn-primary { background: var(--primary); color:white; }
    .btn-xs.btn-outline { border:1px solid var(--border-color); color:var(--text-secondary); background:transparent; }
    .btn-xs.btn-outline:hover { border-color:var(--text-primary); color:var(--text-primary); }
</style>
